
public class Main {
    public static void main(String[] args) {
        System.out.println("Hallo Welt!");
        // todo: Füge hier eine Zeile hinzu, die dein Lieblingshobby erwähnt.
    }
}
