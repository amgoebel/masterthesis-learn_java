
public class Main {
    public static void main(String[] args) {
        // TODO: Füge hier einen Kommentar hinzu, der erklärt, was das Programm macht
        System.out.println("Dies ist der Beginn eines Kurses, der dir Java beibringen soll.");
        /* TODO: Erkläre hier, was dieser Teil des Codes bewirkt */
        System.out.println("Am Ende des Kurses wirst du die Grundlagen der Programmierung mit Java beherrschen");
    }
}
